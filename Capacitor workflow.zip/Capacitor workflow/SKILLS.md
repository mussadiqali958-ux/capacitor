
---
name: capacitor-workflow
description: Guide the development, configuration, testing, troubleshooting, and packaging of Capacitor Android and iOS applications from web projects. Use when working with Capacitor, mobile builds, native plugins, or web-to-mobile deployment.
---

# Capacitor Workflow

## Purpose
Provide a consistent workflow for developing and maintaining mobile applications using Capacitor.

## Workflow

1. Inspect the existing project structure, dependencies, and framework.
2. Identify the package manager and Capacitor configuration.
3. Check Android and iOS platform requirements.
4. Prepare and build the web application.
5. Synchronize web assets and native plugins with Capacitor.
6. Verify application IDs, permissions, and native configuration.
7. Diagnose build or synchronization errors.
8. Test the application on supported devices or emulators.
9. Prepare debug or release builds when requested.
10. Verify outputs before reporting completion.

## Rules
- Preserve the existing project's functionality.
- Avoid unnecessary dependency upgrades.
- Never expose credentials, signing keys, or secrets.
- Do not modify production deployments without authorization.
- Do not assume a build or test succeeded without verification.
- Explain any remaining platform-specific requirements.

## Deliverables
- Updated project files when requested.
- A summary of changes.
- Build and testing results.
- Known limitations and next steps.
