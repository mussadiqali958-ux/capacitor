# PORTABLE PROJECT HANDOVER — HT Capacitor Placement + Line-Loss Optimisation
**Prepared:** 30 October 2026 (Asia/Karachi)  
**Project:** GIS Portal / DISCO Network Intelligence Platform  
**Pilot:** Rail Bazar, Faisalabad City Grid, Pakistan  
**Purpose:** Upload to a **different ChatGPT account** and resume from the latest completed deliverables with no need to explain the whole project again.

## Fastest start — 2 minutes
1. Upload **this handover ZIP** to a new conversation in the other account. If the assistant cannot inspect ZIP files, extract this ZIP locally and upload `00_START_HERE/PASTE_THIS_PROMPT.txt`, `06_DELIVERED_FILES/Rail_Bazar_HT_Capacitor_Loss_Analysis_2026.xlsx`, `06_DELIVERED_FILES/rail_bazar_98_data.csv`, `07_SOURCE_REFERENCES/Formulae Used IN HT - LT Load Flow (1).docx`, and the latest chosen guide/reference files separately. If you have the full package, the original USAID PDF is in `07_SOURCE_REFERENCES/`; if you have the compact package, it is intentionally excluded.
2. Copy the entire text of `00_START_HERE/PASTE_THIS_PROMPT.txt` into the new conversation.
3. Ask the assistant to **confirm file inventory, inspect workbook formulas, verify baseline totals, review QA blockers, and then continue your chosen next task**.
4. Pick a task from `03_PROMPTS/READY_TO_USE_PROMPTS.md` and paste it in the same conversation.

## Where we left off
- **Completed:** 9-sheet Rail Bazar capacitor/line-loss Excel workbook with real *study* section values and editable capacitor assumptions; separate 11 kV capacitor-screening Python/Streamlit prototype; original/revised formula documents; source data table.
- **Not completed / not certified:** true field-verified optimal capacitor location, capacitor installation engineering, validated conductor R/X and switching topology, real metered kW/kVAr timeseries, OpenDSS/time-series validation, live GIS deployment, and NEPRA/FESCO-approved capacitor proposals.
- **Present Excel scenarios:** a 300 kVAr **fixed** bank at ToNode `8320031` and a 150 kVAr **switched** bank at ToNode `8320073`; these are EXAMPLES, not installed devices or verified optimum.
- **Do not change the original GIS model or publish confidential files** without explicit user direction.

## What is inside
- `01_PROJECT_CONTEXT/`: scope, history, existing platform, source-of-truth facts and unresolved items.
- `02_ENGINEERING_GUIDES/`: formulas, Excel guide, Python guide, USAID reference map, technical limitations.
- `03_PROMPTS/`: one-message restart prompt and prompts for Excel improvement, actual optimisation, QA, GIS, reports, deployment.
- `04_TEMPLATES/`: editable inputs and data templates / CSV schema; **templates are blank** and not field observations.
- `05_STATUS_AND_QA/`: data register, acceptance tests, status JSON, file manifest and checksums.
- `06_DELIVERED_FILES/`: prior Excel workbook, 98-section CSV, dashboard preview, revised formula PDF/DOCX, original Python ZIP.
- `07_SOURCE_REFERENCES/`: original HT/LT formula DOCX; plus **full package only**: 152 MB USAID guide PDF.
- `08_PYTHON_STUDIO/`: extracted Python/Streamlit prototype for direct code inspection.

## Crucial warnings
**Actual study data ≠ measured grid telemetry.** The Rail Bazar section IDs, study lengths/currents and modelled kW losses originate in earlier supplied FY25–26 study material, but the capacitor *impact* still depends on assumed PF, operation profile, voltage and reactive power. Prior model topology and GIS discrepancies remain open.

The workbook uses a simplified fixed-voltage, sectional reactive-current sensitivity model. The Python engine is a more physical **balanced radial** backward/forward sweep but ships with **synthetic** feeder data and is not calibrated to Rail Bazar. Do not mix their outputs or report their savings as measured/official.

## Privacy and portability
The handover contains GIS-linked utility-study data and potentially confidential operational context. Share only with accounts and team members authorised to access it. The ZIP does not link or transfer account memory, private GitHub permissions, Google Drive credentials, or connected apps. New accounts must reconnect any required services independently.

## Suggested next action
Complete an **engineering audit and revision of the Excel baseline**, then import validated actual node loading, switching state and conductor R/X into the physical optimisation engine. Do not pick an installation point until voltage, minimum-load Q, harmonics and protection are assessed.
