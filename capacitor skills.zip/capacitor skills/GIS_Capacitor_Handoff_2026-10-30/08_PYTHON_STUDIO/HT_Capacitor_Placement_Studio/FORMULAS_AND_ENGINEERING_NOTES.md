# Revised HT line-loss and capacitor-placement methodology

**Version:** 0.1 screening prototype — 26 October 2026.  **Network:** radial, balanced three-phase 11 kV HT.  **Scope of energy saved:** primary HT conductor I²R losses only; NOT transformer no-load, transformer winding, LT, service cable, commercial or unbilled energy. This preserves the user's historical NEPRA feeder reporting separately from a new scenario engine.

## Source comparison

- **User's document, *Formulae Used IN HT - LT Load Flow*, pp. 1–3:** feeder current, nominal voltage, fixed urban/rural power factor and load-factor settings, `Loss Factor = 0.3 LF + 0.7 LF²`, `3 I² RL / 1000`, feeder energy and voltage drop. These are the **legacy reporting/calculation logic**.
- **USAID, *Power Distribution Planning Guide*, §4.4 and §4.4.1 (printed pp. 38–42; PDF pp. 47–51):** capacitors mainly improve HT line PF/voltage and reduce HT primary technical losses; locate near inductive kVAr loads; 1/2–2/3 distance is a rule of thumb for uniformly distributed loading; evaluate candidates in load flow and only adopt after impact review.
- **USAID Appendix G (printed pp. 113–130, PDF pp. 122–139):** links P, Q, S and PF; fixed banks should be sized for light load to avoid leading PF and overvoltage, switched banks supplement at higher loads. Cap banks may cause excessive voltage and power-quality risks; obtain measured minimum and maximum reactive load.

## Recommended revised calculations

| Step | Engineering formula | Units / implementation |
|:--|:--|:--|
| 1 | `P = sqrt(3) × V_LL × I × PF` | kW when V is kV and I amperes; this is *load real demand*, not apparent demand |
| 2 | `S = sqrt(3) × V_LL × I` | kVA, NOT kW |
| 3 | `Q = P × tan(acos(PF))` | inductive kVAr if PF lags |
| 4 | `Q_c,initial = P × (tan(acos(PF_before)) − tan(acos(PF_target)))` | preliminary kVAr **only**, not placement/sizing approval |
| 5 | `Q_c,actual = Q_c,rated × (V_bus/V_rated)^2` | physical shunt voltage response at nominal frequency |
| 6 | `I_bus = conjugate((P_bus + j×(Q_bus − Q_c,actual)) × 1000 / (3 × V_phase,complex))` | per-phase equivalent A, each load period |
| 7 | `I_section = I_local_downstream + sum(I_child_branches)` | backward/forward sweep; account for all downstream loads and capacitor bank placements |
| 8 | `P_HT,j = 3 × abs(I_j)^2 × (R_j,ohm/km × L_j,km) / 1000` | HT section peak/period kW; consistent with supplied formula |
| 9 | `Q_line,j = 3 × abs(I_j)^2 × (X_j,ohm/km × L_j,km) / 1000` | section inductive kVAr consumption |
| 10 | `V_to,phase = V_from,phase − (R+jX)×L×I_section` | complex radial power flow; iterated until converged |
| 11 | `Voltage_drop_% ≈ 100 × (sqrt(3)×I×(R cosφ + X sinφ)×L) / (1000 × V_LL,kV)` | approximation with matching V units; use solved V bus for official result |
| 12 | `Annual_HT_loss_kWh = sum_period(P_HT_all_sections_kW × period_hours)` | corrected annual method when profile data exist |
| 13 | `Saved_HT_kWh = Annual_HT_loss_before − Annual_HT_loss_after` | if unchanged downstream kW demand and comparable network scenario |
| 14 | `HT_loss_percent_of_metered_TAE = Annual_HT_loss_kWh / TAE_grid_measured_kWh × 100` | only when grid-meter annual TAE is supplied and time-aligned |
| 15 | `Grid_PF = P_grid / sqrt(P_grid² + Q_grid²)` | report lead/lag sign using `Q_grid` independently |
| 16 | `Loss_factor_legacy = 0.3 × LF + 0.7 × LF²` | retain only for **legacy annualisation** / cross-check; do not substitute for seasonal capacitor calculations |

### Changes to the supplied formula document (critical)

1. The user's `Total Feeder Demand = sqrt(3) × I × V` is **apparent power kVA** when I is amperes and V is kV. Multiply by PF to obtain kW. The existing percentage `Total power loss/(demand kVA × PF)` can be reproduced as historical **load-side** ratio, but label its denominator explicitly. Grid-end technical-loss fraction, `P_HTloss/P_grid_injection`, is a *different* metric, not interchangeable.
2. An increased input PF does not, by itself, identify which branch currents decrease. A capacitor at bus N only provides compensation on its upstream supply path. Other branches may remain unchanged; voltage may raise, changing losses and actual kVAr.
3. The user's `LF` and `loss factor` annualisation estimates whole-feeder kWh from peak kW. For fixed/switched banks, the difference of the *two* losses at each load period should be integrated instead. For fixed banks check nighttime / light-load leading PF.
4. The document's `Wire Factor` and voltage-drop presentation rely on implicit scaling; use explicit ohm/km, kV, A, and complex branch voltage model to avoid unit ambiguity. The document itself appends `ΔV = sqrt(3)×I×(Rcosφ+Xsinφ)×L` on page 3. If using `kV` rather than `V`, divide by 1000 as shown.
5. `Transformation Loss = Σ (Copper Loss × Demand Factor² + Core Loss)` remains an existing report assumption, **not** a capacitor impact model. A bank connected on 11 kV **upstream** of a distribution transformer does not automatically reduce that transformer's internal load current. Do not count transformer/LT saving without a separate network branch and device model.
6. `TAE at Grid` is metered energy (if verified); changing LF/PF does not prove new measured energy. Keep **measured**, **modelled**, and **scenario estimates** in separate columns to preserve auditability.

## Screening/optimisation logic

- Build root-to-leaf HT graph from *energized* sections, one incoming line per electrical bus (radial). Reject loops, duplicates, multi-inbound nodes and unknown source switching state.
- Map transformer / consumer kW and lagging kvar to attachment nodes; allocate from actual time-matched kW/kvar if possible; the demo's fixed PF by node is an assumption, not a measurement.
- Evaluate a no-cap baseline for every load period. Enumerate candidate *bus* × standard bank sizes and modes (fixed versus load-threshold switched). Solve circuit flows after adding each bank.
- Reject scenarios with voltage below user limits, overvoltage, over-ampacity, leading grid kVAr in **any** profile period, numerical nonconvergence, and non-positive total annual HT saving.
- Rank feasible proposals by annual HT energy savings. If optional capex, saved kWh value, and assumed life are entered, rank by first-year savings value minus straight-line annualised capex. **This is a simple financial screening, not full discounted NPV.**
- For multiple banks, the MVP adds the next individually best bank greedily and recalculates network impacts. This is not guaranteed optimal across all bank combinations. Treat *planned* sites as candidates; do not energize automatically.

## GIS-based recommendation and reporting data structures

- `nodes.csv`: `node_id`, `peak_kw`, `pf`, `x`, `y` OR `longitude`,`latitude`. ID must be permanent and linked to GIS poles / transformers.
- `sections.csv`: `section_id`, `from_node`, `to_node`, `length_km`, `r_ohm_per_km`, `x_ohm_per_km`, `ampacity_a`. Length/R/X/ampacity **must be traceable** to the conductor master and operating temperature assumptions.
- `profiles.csv`: `period`, `hours`, `load_fraction`, with hours totalling 8760. Use measured demand intervals / load curves where available.
- **Future integration**: `bank_id`, `nominal_kvar`, `step_size_kvar`, `bank_voltage_kv`, controller deadband, switching hysteresis/time delay; 3-phase unbalanced controls; transformer test losses; calibrated head metering; harmonics/flicker and protection records.

## Rail Bazar pilot adaptation / QA gate

The user's previously studied Rail Bazar V14 case reportedly contains **98 unique study sections matched to GIS IDs**, GIS sections represented by **101 geometry pieces**, 77 transformers, and approximately 24.666 kW previously **modelled** peak HT line losses. This does **not** mean all electrical nodes are verified: prior review flagged **five multi-inbound electrical node IDs** and **three conductor multi-geometry discrepancies**, plus R/X and switching-data gaps. Do NOT double count multi-part GIS geometry as electrical sections. Resolve switching/electrical nodes and validated conductor R/X values before using the optimisation for actual capacitor recommendations. This delivered package contains no private feeder data and does not modify the existing City Grid/Rail Bazar project.

## Validation and deployment rules

Check no-cap predicted peak grid current, low voltage and `Σ HT section loss kW` against the original validated feeder study. Align source dates and loads; calibrate to grid/transformer readings. Then physically verify proposed pole access, upstream protection coordination/fusing, capacitor discharge/earthing, available reactive kVAr at minimum load, harmonic resonance, voltage step/flicker, transient inrush, and 11 kV insulation/clearance. Operations engineering must approve all designs. Use an unbalanced 3-phase power-flow and time-series power-quality tool (e.g. OpenDSS) for certification.

**External implementation reference:** pandapower shunt reference model specifies V² behaviour and shunt convention; OpenDSS supports capacitors and control models. A pandapower shunt `q_mvar` load-sign convention must not be mixed with a *positive injected* kvar UI entry.
