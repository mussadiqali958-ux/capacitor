"""HT Capacitor Placement Studio: start with `streamlit run app.py`."""
from __future__ import annotations
import math
import json
from pathlib import Path
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from engine import Feeder, Bank, ModelError, annual, compare, candidates, greedy_banks, validate_profile

st.set_page_config(page_title='HT Capacitor Placement Studio',page_icon='⚡',layout='wide')
st.markdown('''<style>
.block-container{padding-top:1.1rem;max-width:1550px}
[data-testid="stMetric"]{background:#f4f7fc;padding:15px;border-radius:12px;border:1px solid #e4eaf4}
small{color:#475569}
</style>''',unsafe_allow_html=True)

st.title('⚡ HT Capacitor Placement Studio')
st.caption('11 kV | GIS node-by-node model | reactive power compensation | HT technical loss & voltage screening')
st.info('Engineering screening model: balanced, radial, constant-PQ load assumptions. Results are estimates, NOT a switching instruction or certified installation design. No actual Faisalabad data are included in the demonstration files.',icon='ℹ️')

BASE=Path(__file__).resolve().parent/'sample_data'
with st.sidebar:
    st.header('1 · Import feeder data')
    st.caption('Load own CSVs or use the labelled synthetic sample.')
    upload_n=st.file_uploader('Nodes: nodes.csv',type='csv',key='n')
    upload_s=st.file_uploader('HT sections: sections.csv',type='csv',key='s')
    upload_p=st.file_uploader('Annual load profile: profiles.csv',type='csv',key='p')
    nodes=pd.read_csv(upload_n or BASE/'nodes.csv',dtype={'node_id':str})
    sections=pd.read_csv(upload_s or BASE/'sections.csv',dtype={'section_id':str,'from_node':str,'to_node':str})
    profiles=pd.read_csv(upload_p or BASE/'profiles.csv')
    if not(upload_n and upload_s):st.warning('Synthetic demonstration data currently loaded.')
    st.header('2 · Electrical model')
    root=st.selectbox('Source / root bus ID',nodes.node_id.astype(str).tolist(),index=0)
    vn=st.number_input('Nominal L-L voltage (kV)',min_value=3.0,max_value=33.0,value=11.0,step=.5)
    volt_min,volt_max=st.slider('Permissible voltage (pu)',min_value=.90,max_value=1.10,value=(.95,1.05),step=.005)
    switch_threshold=st.slider('Switched bank ON from load fraction',.1,1.0,.60,.05)
    st.header('3 · Capacitor sizing')
    size_str=st.text_input('Candidate sizes (kVAr)',value='150,300,450,600,900')
    kind=st.radio('Capacitor operation',options=['fixed','switched'],horizontal=True)
    bank_count=st.select_slider('Max proposed banks',options=[1,2,3],value=1)
    st.header('4 · Economics (optional)')
    calculate_economics=st.checkbox('Include indicative economics',value=False)
    if calculate_economics:
        price=st.number_input('Value of saved energy (PKR/kWh)',min_value=.1,value=25.0,step=1.0)
        cost=st.number_input('Installed bank cost (PKR/kVAr)',min_value=1.0,value=6000.0,step=500.0)
        life=st.number_input('Evaluation life (years)',min_value=1,max_value=30,value=15)
    else:price=cost=life=None
    metered_tae=st.number_input('Metered annual feeder-grid TAE (kWh; 0 = unknown)',min_value=0.0,value=0.0,step=10000.0)

try:
    sizes=sorted({float(s.strip()) for s in size_str.split(',') if s.strip()})
    if not sizes or any(x<=0 for x in sizes):raise ModelError('Candidate bank sizes must be positive')
    feeder=Feeder(nodes,sections,root,vn)
    profiles=validate_profile(profiles)
    base=annual(feeder,profiles)
    peak_fraction=float(profiles.load_fraction.max())
    peak_base=feeder.run(peak_fraction)
except Exception as e:
    st.error(f'Model validation failed: {e}');st.stop()

k1,k2,k3,k4,k5=st.columns(5)
k1.metric('HT nodes',len(feeder.nodes))
k2.metric('HT sections',len(feeder.sections))
k3.metric('Total HT route',f'{feeder.sections.length_km.sum():,.2f} km')
k4.metric('Baseline annual HT loss',f'{base["annual_kwh"]/1000:,.1f} MWh')
k5.metric('Peak source power factor',f'{peak_base["source_pf"]:.3f}' + (' lead' if peak_base['leading'] else ' lag'))

if metered_tae>0:
    ratio=base['annual_kwh']/metered_tae*100
    st.caption(f'Metered TAE reference: {metered_tae:,.0f} kWh | Modelled baseline HT technical loss / metered TAE: {ratio:.3f}% | Modelled annual grid import: {base["modelled_grid_kwh"]:,.0f} kWh (profile-dependent; must reconcile with metering).')
else:
    st.caption(f'Modelled grid annual import (not metered): {base["modelled_grid_kwh"]:,.0f} kWh. Optional actual TAE improves reconciliation, but does not replace measured load profiles.')

tab1,tab2,tab3,tab4=st.tabs(['📍 Placement optimizer','🧪 What-if analysis','🗺️ Network / section impact','🛡️ Data quality & methodology'])

with st.spinner('Evaluating feasible bank sizes and locations across all profile periods...'):
    kw=dict(vmin=volt_min,vmax=volt_max,threshold=switch_threshold)
    if calculate_economics:
        kw.update(cap_cost_per_kvar=cost,energy_value_per_kwh=price,cap_life_years=life)
    try:
        ranked=candidates(feeder,profiles,sizes=sizes,kind=kind,limit=max(800,len(feeder.order)*len(sizes)),**kw)
        selected_banks,history=greedy_banks(feeder,profiles,n_banks=bank_count,sizes=sizes,kind=kind,**kw)
    except ModelError as e:
        st.error(str(e));st.stop()

if selected_banks:
    chosen=compare(feeder,profiles,selected_banks,base,switch_threshold)
else:
    chosen=compare(feeder,profiles,[],base,switch_threshold)

with tab1:
    st.subheader('Best feasible solution')
    if selected_banks:
        st.write(' + '.join(f'**{b.kvar:g} kVAr at {b.node_id}** ({b.kind})' for b in selected_banks))
        a,b,c,d=st.columns(4)
        a.metric('Estimated annual HT saving',f'{chosen["saved_kwh"]/1000:,.1f} MWh')
        b.metric('HT loss reduction',f'{chosen["saved_pct"]:,.2f}%')
        c.metric('Post minimum voltage',f'{chosen["proposed"]["min_pu"]:.4f} pu')
        d.metric('Post maximum line loading',f'{chosen["proposed"]["max_loading_pct"]:.1f}%')
    else:
        st.warning('No feasible location / size passes all limits across all periods. Review actual feeder data, voltage limits and small bank sizes; do not override safety constraints to force a result.')
    st.caption('Ranking is exhaustive for ONE bank. Two/three-bank solution uses sequential greedy additions, not a guaranteed globally optimal combination.')
    feasible=ranked[ranked.feasible==True].copy() if len(ranked) else pd.DataFrame()
    if len(feasible):
        fields=['node_id','kvar','kind','saved_kwh','saved_pct','post_loss_kwh','v_min_pu','v_max_pu','max_loading_pct']
        if calculate_economics: fields+=['capex','annual_benefit','annual_net_value','payback_years']
        st.dataframe(feasible[fields].head(30),hide_index=True,use_container_width=True)
    with st.expander('View rejected / non-feasible candidates'):
        bad=ranked[ranked.feasible==False] if len(ranked) else pd.DataFrame()
        st.dataframe(bad[['node_id','kvar','reason']].head(100) if len(bad) else bad,hide_index=True,use_container_width=True)
    st.download_button('Download candidate ranking (CSV)',data=ranked.to_csv(index=False).encode('utf-8'),file_name='ht_capacitor_candidate_ranking.csv',mime='text/csv')
    export={'model':'balanced radial load flow (backward-forward sweep)','source':root,'nominal_kv':vn,
        'banks':[x.__dict__ for x in selected_banks],'annual_ht_base_loss_kwh':base['annual_kwh'],
        'annual_ht_post_loss_kwh':chosen['proposed']['annual_kwh'],'annual_ht_saving_kwh':chosen['saved_kwh'],
        'annual_ht_saving_pct':chosen['saved_pct'],'data_source':'uploaded feeder CSV' if upload_n and upload_s else 'SYNTHETIC demonstration, not an actual feeder'}
    st.download_button('Download study summary (JSON)',json.dumps(export,indent=2).encode('utf-8'),file_name='ht_capacitor_study_summary.json',mime='application/json')

with tab2:
    st.subheader('Manual scenario | change location, size, and switching')
    with st.form('scenario'):
        x,y,z=st.columns(3)
        manual_node=x.selectbox('Bank location',list(feeder.order[1:]),index=0)
        manual_kvar=y.number_input('Bank size (kVAr)',min_value=1.0,value=300.0,step=50.0)
        manual_kind=z.radio('Bank mode',['fixed','switched'],horizontal=True)
        submit=st.form_submit_button('Calculate impact')
    if submit: st.session_state.manual=(manual_node,float(manual_kvar),manual_kind)
    scenario=st.session_state.get('manual',None)
    if scenario and scenario[0] in feeder.order:
        comp=compare(feeder,profiles,[Bank(*scenario)],base,switch_threshold)
        k1,k2,k3=st.columns(3)
        k1.metric('Before annual HT loss',f'{comp["base"]["annual_kwh"]:,.0f} kWh')
        k2.metric('After annual HT loss',f'{comp["proposed"]["annual_kwh"]:,.0f} kWh')
        k3.metric('Saving',f'{comp["saved_kwh"]:,.0f} kWh',delta=f'{comp["saved_pct"]:.2f}%')
        if comp['proposed']['any_leading'] or comp['proposed']['max_pu']>volt_max or comp['proposed']['min_pu']<volt_min or comp['proposed']['max_loading_pct']>100:
            st.error('Proposed manual case violates voltage/loading/leading-PF constraints; not recommended.')
        local_banks=[Bank(*scenario)]
    else:
        comp=chosen
        local_banks=selected_banks
    baseline=comp['base']['periods']
    proposed=comp['proposed']['periods']
    c1,c2=st.columns([1.3,1])
    with c1:
        fig=go.Figure()
        fig.add_bar(x=baseline.period,y=baseline.loss_kwh,name='Before — kWh')
        fig.add_bar(x=proposed.period,y=proposed.loss_kwh,name='After — kWh')
        fig.update_layout(title='HT energy loss across annual loading periods',barmode='group',yaxis_title='kWh',height=390)
        st.plotly_chart(fig,use_container_width=True)
    with c2:
        cmp=baseline[['period','hours','load_fraction','loss_kw','loss_kwh','source_pf','min_pu']].merge(proposed[['period','loss_kw','loss_kwh','source_pf','min_pu']],on='period',suffixes=('_before','_after'))
        cmp['saved_kwh']=cmp.loss_kwh_before-cmp.loss_kwh_after
        st.dataframe(cmp,hide_index=True,use_container_width=True)
        st.download_button('Download scenario comparison (CSV)',cmp.to_csv(index=False).encode('utf-8'),'ht_scenario_comparison.csv',mime='text/csv')

with tab3:
    st.subheader('Connected HT feeder topology · before / after peak section losses')
    post_peak=feeder.run(peak_fraction,selected_banks,switch_threshold)
    old=pd.DataFrame(peak_base['lines']).set_index('section_id')
    new=pd.DataFrame(post_peak['lines']).set_index('section_id')
    diff=old[['from_node','to_node','loss_kw','current_a','end_voltage_pu']].join(new[['loss_kw','current_a','end_voltage_pu']],lsuffix='_before',rsuffix='_after')
    diff['saved_kw']=diff.loss_kw_before-diff.loss_kw_after
    diff=diff.sort_values('saved_kw',ascending=False)
    st.dataframe(diff.reset_index().head(50),hide_index=True,use_container_width=True)
    st.download_button('Download all section impacts (CSV)',diff.reset_index().to_csv(index=False).encode('utf-8'),'ht_section_impacts.csv',mime='text/csv')
    # Draw supplied coordinates when present; otherwise layout is schematic only.
    if {'x','y'}.issubset(feeder.nodes.columns):
        xy={str(r.node_id):(float(r.x),float(r.y)) for r in feeder.nodes.itertuples()}
        axis_title='Provided X/Y (schematic sample unless actual GIS projected coordinates supplied)'
    elif {'longitude','latitude'}.issubset(feeder.nodes.columns):
        xy={str(r.node_id):(float(r.longitude),float(r.latitude)) for r in feeder.nodes.itertuples()}
        axis_title='Longitude / Latitude (geographical plot; not a basemap)'
    else:
        xy={n:(float(i),float(-i%7)) for i,n in enumerate(feeder.order)}
        axis_title='Schematic layout only — upload coordinates for spatially correct placement'
    fig=go.Figure()
    csave=diff['saved_kw'].to_dict()
    maximum=max([abs(v) for v in csave.values()],default=1) or 1
    for l in feeder.sections.itertuples():
        a,b=xy[l.from_node],xy[l.to_node]
        saving=csave.get(l.section_id,0)
        intensity=max(0,min(1,saving/maximum))
        colour='rgb('+','.join(str(round(x)) for x in (65+150*intensity,105-50*intensity,160-100*intensity))+')'
        fig.add_trace(go.Scatter(x=[a[0],b[0]],y=[a[1],b[1]],mode='lines',line=dict(color=colour,width=2.5+3*intensity),
            hovertext=f'{l.section_id} | saving {saving:.3f} kW',hoverinfo='text',showlegend=False))
    fig.add_trace(go.Scatter(x=[xy[n][0] for n in feeder.order],y=[xy[n][1] for n in feeder.order],mode='markers+text',
        text=list(feeder.order),textposition='top center',marker=dict(size=7,color='#174975'),name='HT nodes'))
    if selected_banks:
        fig.add_trace(go.Scatter(x=[xy[b.node_id][0] for b in selected_banks],y=[xy[b.node_id][1] for b in selected_banks],
            mode='markers+text',text=[f'{b.kvar:g} kVAr' for b in selected_banks],textposition='bottom center',
            marker=dict(size=18,color='#e49a27',symbol='diamond',line=dict(width=2,color='#fff')),name='Proposed bank'))
    fig.update_layout(height=570,title=axis_title,xaxis=dict(showgrid=False,zeroline=False),yaxis=dict(showgrid=False,zeroline=False,scaleanchor='x'),margin=dict(l=25,r=25,t=70,b=20))
    st.plotly_chart(fig,use_container_width=True)
    st.caption('Section colour intensity reflects estimated *peak kW saved* by selected banks; this is not a conductor heat map or exact GIS map unless real node coordinates are supplied.')

with tab4:
    st.subheader('Engineering checks before a DISCO planning proposal')
    quality=pd.DataFrame([('Single root and connected radial topology','PASS'),
        ('Duplicate section / nodes / incoming connections','PASS'),
        ('Physically supplied conductor R/X and thermal ratings','USER CONFIRMATION REQUIRED'),
        ('Source metering I/V/PF time series','NOT INCLUDED IN DATA MODEL'),
        ('Phase unbalance / neutral currents','NOT MODELLED'),
        ('Switch status / feeder ties / network protection','TOPOLOGY USER CONFIRMATION'),
        ('Capacitor switching transients, harmonics, resonance','SEPARATE ENGINEERING STUDY'),
        ('Detailed transformer copper / core and LT losses','NOT MODELLED; HT LINE LOSSES ONLY'),
        ('Actual annual bill / TAE reconciliation','NOT VERIFIED'),
        ('On-site bank pole, clearance, fusing, earthing','SITE DESIGN REQUIRED')],columns=['Requirement','Status'])
    st.dataframe(quality,hide_index=True,use_container_width=True)
    st.markdown('''**Formula basis.** Section HT loss = `3 × I_section² × R_section(Ω/km) × L(km) / 1000` kW. Bank output varies approximately with `V²`. Annual HT energy loss = `Σ(period load-flow HT loss kW × period hours)`. The old load-loss-factor equation is retained only as a reporting estimate for comparison, not applied to compensate each branch.

**Scope.** Source is set by root bus. Loads are balanced, inductive, and constant kW/kVAr per time period. Backward-forward sweep solves bus voltages and branch currents. Fixed capacitor is active during all periods. Switched capacitor is active when the period's load fraction reaches the specified threshold. Candidates violating voltage, ampacity, leading grid reactive power or negative net annual savings are rejected.

**USAID reference.** *Power Distribution Planning Guide*, §§4.4–4.4.1 (printed pp. 38–42); Appendix G (printed pp. 113–130). Location around ½–⅔ feeder distance is illustrative for uniform loads, not an optimizer rule. Actual installations require expert design and voltage/power-quality/protection review.''')
