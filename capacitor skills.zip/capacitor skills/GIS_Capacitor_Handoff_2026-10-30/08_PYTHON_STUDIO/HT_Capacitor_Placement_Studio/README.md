# HT Capacitor Placement Studio — DISCO / 11 kV GIS pilot

A working, **offline-capable local** first prototype for bus-by-bus capacitor placement and scenario HT losses. It implements a 3-phase **balanced**, radial backward-forward sweep, an annual load-profile integration, feasibility screens and a Streamlit visual portal. All input CSVs are kept on the local computer; the application does not upload them to GitHub or a remote server. Package contains **synthetic demonstration data only**.

## Start in Windows

1. Install Python 3.11 or newer.
2. Extract this ZIP and double-click `run_windows.bat`, or in terminal:
   ```powershell
   py -m pip install -r requirements.txt
   py -m streamlit run app.py
   ```
3. Browser opens local Streamlit app. Enter own feeder CSVs through left panel to replace the sample.
4. Select the *electrically verified* source bus, voltage/limits, fixed or switched, candidate kVAr bank sizes and number of banks. Candidate ranking / section loss comparison / JSON report can be downloaded from the portal.

## Run without a graphical interface

```powershell
py cli.py --folder sample_data --source N0 --kind fixed --banks 2
```

CLI writes `outputs/ranking.csv`, `recommended_banks.csv`, `before_by_period.csv`, `after_by_period.csv`. No internet needed after Python dependencies are installed.

## Import schema

`nodes.csv`:

| node_id | peak_kw | pf | x | y |
|---|---:|---:|---:|---:|
| N0 | 0 | 1 | 0 | 0 |
| N1 | 200 | 0.85 | 1 | 0 |

`sections.csv`:

| section_id | from_node | to_node | length_km | r_ohm_per_km | x_ohm_per_km | ampacity_a |
|---|---|---|---:|---:|---:|---:|
| S1 | N0 | N1 | 0.3 | 0.34 | 0.30 | 250 |

`profiles.csv`:

| period | hours | load_fraction |
|---|---:|---:|
| Peak | 1600 | 1.00 |
| Medium | 4900 | 0.6 |
| Low | 2260 | 0.3 |

Totals must equal 8760 h (non-leap year). Example files are completely synthetic and are not real GIS coordinates/utility operating measurements.

**Source / root node:** supply at 11 kV (or entered L-L voltage). **Pole allocation:** individual node `peak_kw` must be coincident demand at the study peak (not nameplate sum). `pf` is node lagging PF. Do not mix kVA and kW. `x,y` are for drawing only; calculations use real `length_km` from sections. Optional lat/lon can be used for geographical plotted points.

## Explicit limitations

1. **Do not interpret initial recommendation as an installed/approved bank**. The engine deliberately refuses multi-inbound or looped topologies until switch configurations are resolved.
2. Calculates **HT conductor line savings only**. No transformer/LT loss savings, capacitor dielectric watts, upstream substation losses, unsold energy, or revenue collection improvements included. Commercial/administrative losses cannot be reduced just by capacitor placement.
3. Balanced three-phase constant-PQ loads; no unbalanced phases, magnetising harmonics, voltage regulators/taps, load-voltage dependence, capacitor transients, power-quality, feeder reconfiguration, or temperature corrections.
4. Fixed banks remain connected in all periods. Switched banks use a simple *load-fraction threshold*, NOT hardware-grade voltage/PF time-delay/deadband switching.
5. Optimisation finds the best one-bank location/size among user-specified candidates. Multiple-bank screening uses greedy sequential allocation, not exhaustive global optimisation.
6. Annual kWh depends on 8760-hour load-profile approximation: validated 15-60 min profiles and capacitor controller schedule will substantially improve accuracy.
7. Indicative financial values are user-entered, default **off**; the package makes no claim to up-to-date market capacitor costs.

## Folder contents

- `app.py`: user interface and comparison charts
- `engine.py`: physical electrical screening and candidate ranking
- `cli.py`: local CSV batch processing
- `sample_data/`: fabricated 11 kV test feeder
- `tests/`: model physics and QA regression tests
- `FORMULAS_AND_ENGINEERING_NOTES.md`: user's existing formulas vs revised method, source page references, and feeder integration rules
- `run_windows.bat`: local launcher

## Next production milestone — Rail Bazar / City Grid

Use existing 98-study-section Rail Bazar network source when available. **No private Rail Bazar data are in this ZIP**. GIS geometry can have multiple pieces per electrically unique section. Verify the 5 multi-inbound electrical nodes / switch state, remaining conductor discrepancies, source-grid metering and R/X before mapping to this schema. When resolved, connect transformer-to-node loading (kW/kvar by period), plot actual 11 kV line geometry, and add OpenDSS for unbalanced & controller time-series studies. Keep original City Grid models intact until validation is approved.

### Local-only configuration

`.streamlit/config.toml` binds the app to loopback `127.0.0.1` and turns off Streamlit product usage telemetry. Packages are downloaded from Python's package index on the initial installation only. Do not use Streamlit's public Community Cloud for confidential GIS files.
