"""GENERATED DEMONSTRATION ONLY — NOT AN ACTUAL FESCO RAIL BAZAR FEEDER."""
from pathlib import Path
import pandas as pd
D=Path(__file__).resolve().parent/'sample_data';D.mkdir(exist_ok=True)
# 11 kV source, multi-branch synthetic feeder. Coordinates are arbitrary plot xy, not real GPS.
nodes=[('N0',0,1,0,0),('N1',60,.88,1,0),('N2',240,.85,2,0),('N3',280,.83,3,0),
('N4',180,.85,4,0),('N5',350,.81,5,0),('N6',230,.82,6,0),('N7',150,.86,3,1),
('N8',420,.78,4,1),('N9',270,.84,5,1),('N10',400,.8,4,2),('N11',230,.82,2,-1),
('N12',340,.80,3,-1),('N13',190,.84,4,-1),('N14',330,.81,5,-1),('N15',290,.83,6,-1)]
sections=[('S01','N0','N1',.38,.28,.32,425),('S02','N1','N2',.56,.28,.32,425),
('S03','N2','N3',.60,.37,.34,290),('S04','N3','N4',.44,.37,.34,290),
('S05','N4','N5',.60,.48,.35,230),('S06','N5','N6',.62,.48,.35,230),
('S07','N3','N7',.43,.48,.35,220),('S08','N7','N8',.48,.48,.35,220),
('S09','N8','N9',.52,.48,.35,220),('S10','N8','N10',.30,.48,.35,220),
('S11','N2','N11',.44,.48,.35,220),('S12','N11','N12',.48,.48,.35,220),
('S13','N12','N13',.65,.48,.35,220),('S14','N13','N14',.40,.48,.35,220),
('S15','N14','N15',.36,.48,.35,220)]
pd.DataFrame(nodes,columns=['node_id','peak_kw','pf','x','y']).to_csv(D/'nodes.csv',index=False)
pd.DataFrame(sections,columns=['section_id','from_node','to_node','length_km','r_ohm_per_km','x_ohm_per_km','ampacity_a']).to_csv(D/'sections.csv',index=False)
pd.DataFrame([('Peak',1500,1.0),('High',2300,.75),('Medium',3060,.52),('Low',1900,.29)],columns=['period','hours','load_fraction']).to_csv(D/'profiles.csv',index=False)
print('Created clearly labelled SYNTHETIC feeder inputs in sample_data/')
