"""Offline/non-UI analysis. Run: python cli.py --folder sample_data --source N0"""
import argparse
from pathlib import Path
import pandas as pd
from engine import Feeder,validate_profile,annual,candidates,greedy_banks,compare

p=argparse.ArgumentParser();p.add_argument('--folder',default='sample_data');p.add_argument('--source',default='N0')
p.add_argument('--voltage',type=float,default=11.0);p.add_argument('--kind',choices=['fixed','switched'],default='fixed')
p.add_argument('--sizes',default='150,300,450,600,900');p.add_argument('--banks',type=int,default=1);p.add_argument('--output',default='outputs')
a=p.parse_args();folder=Path(a.folder);out=Path(a.output);out.mkdir(exist_ok=True,parents=True)
n=pd.read_csv(folder/'nodes.csv',dtype={'node_id':str})
l=pd.read_csv(folder/'sections.csv',dtype={'section_id':str,'from_node':str,'to_node':str})
f=Feeder(n,l,a.source,a.voltage)
profile=validate_profile(pd.read_csv(folder/'profiles.csv'))
sizes=[float(s) for s in a.sizes.split(',')]
rank=candidates(f,profile,sizes,kind=a.kind,limit=100000)
banks,hist=greedy_banks(f,profile,a.banks,sizes,kind=a.kind)
result=compare(f,profile,banks)
rank.to_csv(out/'ranking.csv',index=False)
hist.to_csv(out/'recommended_banks.csv',index=False)
result['proposed']['periods'].to_csv(out/'after_by_period.csv',index=False)
result['base']['periods'].to_csv(out/'before_by_period.csv',index=False)
print('SOURCE',a.source,'CAPACITORS',banks)
print('Baseline HT loss kWh/year:',round(result['base']['annual_kwh']))
print('New HT loss kWh/year:',round(result['proposed']['annual_kwh']))
print('Estimated saving kWh/year:',round(result['saved_kwh']),'(',round(result['saved_pct'],2),'%)')
print('Output files:',out.resolve())
