# Engineering guide — line losses before/after shunt capacitor placement

**Status:** reference design and screening methodology; not construction/installation approval. Original planning reference: USAID *Power Distribution Planning Guide*, §4.4–4.4.1 (PDF pages about 47–51; printed pp. 38–42), Appendix G (PDF about 120–139; printed pp. 111–130); supplied three-page `Formulae Used IN HT - LT Load Flow (1).docx`.

## A) Three separate evidence classes
- **Actual from user-supplied study:** SectionIDs, directed parent chain, source/target nodes, study lengths, conductor labels, reported peak currents, `LossKW`, cumulative VD as published (rounded), and GIS QA table. These are **study model values**, not direct field metering.
- **Derived from study:** effective resistance `R_eff = 1000*P_study/(3*I_study^2*L)` when quantities are nonzero; it reproduces the rounded study loss at the supplied current but is *not* an approved conductor electrical master value. GIS length mismatch and reconstructed paths likewise derive from model data.
- **Assumed illustrative:** PF (0.85 common default), 11 kV fixed bus, load fractions/hours, proposed capacitors 300 fixed + 150 switched kVAr, switched threshold, controller/voltage effects, bank losses and economic inputs. Such assumptions should be conspicuous and editable.

## B) Consistent three-phase equations
- At voltage `V_LL` (kV) and current `I` (A): `S_kVA = sqrt(3)*V_LL*I` ; `P_kW = S_kVA*PF` ; `Q_kVAr = P_kW*tan(acos(PF))` for lagging inductive load.
- Initial target-PF sizing: `Q_c[kVAr] = P[kW]*(tan(acos(PF_before)) - tan(acos(PF_target)))`. This determines an initial bank size, *not* its location or acceptability.
- Voltage-sensitive capacitor: `Q_c,actual = Q_c,rated*(|V_bus|/V_rated)^2` (for fixed frequency); fixed remains energised at all periods, switched according to controller and demand/time, respecting minimum-load PF.
- Physical balanced three-phase HT sectional copper loss: `P_loss_section,kW = 3*|I_section|^2*R_ohm_per_km*L_km/1000`. Network line loss = sum of **unique electrical** sections, not geometry pieces.
- Approximate voltage drop: `DeltaV_LL,V ~= sqrt(3)*I_A*(R*cos(phi)+X*sin(phi))*L_km` with R/X in ohm/km. `VD_pct ~= 100*DeltaV_LL,V/(1000*V_LL,kV)`; complex nodal voltage is preferred.
- Legacy annualisation when no time series: `LossFactor = 0.3*LF + 0.7*LF^2`, `E_loss,kWh ~ P_peak_loss,kW*LossFactor*8760`. **Preserve as a historical reporting comparison only**.
- Preferred period annualisation: `E_loss = sum over cases t [sum sections P_loss_section,t * h_t]`; `E_saved = E_baseline-E_cap` (subtract bank active losses and other modelled impacts if separately quantified). All periods' hours must sum to **8760** for a non-leap-year full annual model.
- Physical radial load flow: for each period allocate `P_i,Q_i` to bus i; subtract injected capacitor kvar; solve current using `I_i = conj(S_i/(3*V_phase,i))` with all quantities converted consistently to VA; backward sum currents through sections, forward solve `V_child=V_parent-Z_section*I_section`; iterate until convergence. Recalculate voltage-dependent capacitor output and losses each iteration.
- Feeder PF must include the **sign** of net Q. `P/sqrt(P^2+Q^2)` alone masks a leading PF; record signed Q and leading/lagging state separately.

## C) Why whole-feeder PF replacement is wrong
A capacitor at bus N reduces reactive supply current only along energised branches connecting **source → N**. It does **not** remove reactive power in independent downstream/lateral branches. For a meaningful location recommendation, feeder topology, node loads and branch impedance are necessary. The USAID "1/2 to 2/3 of feeder length" is a starting heuristic for a simplified uniformly distributed case, **not** a universal rule or an automatic install location.

## D) Workbook vs physical model
**Excel v2026:** uses the published peak loss `LossKW` as its baseline; builds section P,Q from *each section's study current* and assumed PF at fixed 11 kV; for proposed capacitor, subtracts kVAr only in the ancestor sections of its node; calculates post-cap current from `sqrt(P^2+Q_net^2)/(sqrt(3)*V)`; scales published loss by current ratio squared, integrates three operating cases. This reproduces study losses and allows interactive sensitivity, but ignores voltage-dependent bank kvar, network voltage change, true R/X, harmonics, dynamic controller, per-phase imbalance, alternative switching and detailed transformer/LT impacts.

**Python v0.1:** uses a balanced radial backward-forward sweep with physical R/X data in the **synthetic** example. It can rank site/size under specified constraints but cannot run correctly on real Rail Bazar until unambiguous network, correct R/X, section loading and metered profiles have been imported.

## E) Before/after method for real engineering upgrade
1. Establish *as-operated* network: source bus, switches, topology by time, energized feeder sections, tie status, unique upstream branch per radial bus. Confirm GIS multipart geometry vs electrical section identity.
2. Build conductor electrical master (resistance at temperature, reactance, thermal ampacity, conductor type and phase configuration) and record data provenance/units.
3. Build nodal loads from measured transformer/consumer `P,Q` and coincident feeder profile. Do not use installed transformer kVA as actual demand.
4. Calibrate without-cap scenario to source metering (A, kV, kW, kVAr, PF), section/transformer inspections and measured voltages across peak and minimum cases. Reconcile losses and demand independently.
5. Generate eligible bus sites (physical access/protection/constructability) and standard bank sizes (standard sizes sourced locally, not invented). Model fixed and switched operation including hysteresis, time delay and minimum load.
6. Evaluate all candidate scenarios across load periods and abnormal/normal switch cases. Reject overvoltage, undervoltage, ampacity/thermal violations, excessive leading PF, protection and power-quality hazards; a switched bank may be appropriate where a fixed bank overcompensates.
7. Rank feasible sites by **annual net loss saved**, verified voltage regulation, capacitance utilisation, indicative economics and physical feasibility; report excluded candidates and reasons.
8. Issue engineering review package with map, source SectionIDs/NodeIDs, assumptions/data lineage, comparative losses, PF, volts, kWh, bank kvar, cost, QC, validation records and approval workflows.

## F) Do not double-count other losses
A bank on 11 kV primary mainly affects upstream HT feeder current; LT and service losses downstream need their own electrical model and capacitor location. An upstream 11 kV bank does **not** automatically reduce a distribution transformer's secondary/low-voltage current. Keep transformation no-load, copper loss, LT conductor, service/drop, nontechnical and billing components in separate categories.

## G) Production-grade feasibility gates
- Confirm no leading PF at minimum load and no overvoltage; check light-load feeder reactive requirements before fixed-bank sizing.
- Check node-voltage profile, regulator taps, step changes, harmonics/resonance, switching inrush and flicker, fault duty and relay/fuse coordination, discharge resistors, earthing, safe clearances, protection and pole/structure constructability.
- Distinguish preliminary model results from actual performance and approvals. Independent utility electrical/operations engineer must approve field placement.

## H) Legacy supplied formula inputs and caveats
The original supplied DOCX lists: grid peak amps, 11–11.5 kV (default 11), urban PF 0.85 and rural PF 0.8, urban/rural/mixed LF 0.6/0.4/0.5, TAE at grid, growth, loss factor `0.3LF+0.7LF²`, `3I²RL/1000`, transformer loss approximation `sum(copper*DF² + core)`, and voltage drop formula. In that older calculation, `sqrt(3)*V(kV)*I(A)` is **kVA, not kW**. Multiply by PF for kW. Do not silently modify historically submitted values; add corrected engineering columns alongside as a new scenario method.
