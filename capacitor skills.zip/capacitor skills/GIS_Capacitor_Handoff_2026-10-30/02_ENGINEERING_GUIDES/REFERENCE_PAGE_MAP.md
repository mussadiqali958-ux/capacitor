# Source references and where to read

## USAID Power Distribution Planning Guide
**Original complete PDF in full package:** `07_SOURCE_REFERENCES/USAID Plaining Guide (for DISCOs).pdf` (~152 MB, original user's filename preserved, 234 PDF pages). The compact package excludes this large PDF; it includes source-based notes and this page map instead. Find the original PDF in the conversation if you need exact text/figures.

- **PDF pp. 47–51** / printed pp. 38–42: Section **4.4 Installation of HT Capacitors**, **4.4.1 Capacitor Location**, placement rule-of-thumb 1/2 to 2/3 for simplified uniform feeders, importance of industrial load centres, feeder studies, SynerGEE procedure, compare before/after placement effects.
- **PDF pp. 120–139** / printed pp. 111–130: Appendix **G Capacitor Sizing, Location, and Use**, relationship between P/Q/S/PF, shunt/series options, fixed/switched load conditions, voltage profile, leading PF risk, sizing and controller application, judgement factors.
- **PDF pp. 86–95** / printed ~77–86: Appendix B important power and feeder-loss formulas.
- **PDF p. 65** / printed p. 56: proposal engineering permissible limits and prioritisation context; do NOT apply generic values as formal site-specific capacitor approval criteria without utility confirmation.

## Original HT–LT load-flow formula sheet
**File:** `07_SOURCE_REFERENCES/Formulae Used IN HT - LT Load Flow (1).docx` (three pages). HT formulas on p.1, LT formulas p.2, appended voltage-drop expression on p.3. This is a supplied baseline methodology; the revised formula document in `06_DELIVERED_FILES/` interprets/update it for capacitor impact modelling without retroactively changing any submitted regulatory report.

## Revised formula and engineering documents
`06_DELIVERED_FILES/Revised_HT_Capacitor_Loss_Formulas_2026.docx` and `.pdf`. Additional extensive notes in `08_PYTHON_STUDIO/HT_Capacitor_Placement_Studio/FORMULAS_AND_ENGINEERING_NOTES.md`.

## Source citation practice
In reports distinguish: **(i)** user-supplied guide statement, **(ii)** original study output, **(iii)** spreadsheet formula result, **(iv)** numerical assumption, **(v)** external engineering standard not supplied. Do not fabricate page citations, switch statuses, transformer metering, financial inputs or field test certifications.
