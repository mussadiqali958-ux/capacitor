# Existing Excel workbook — detailed operating and audit guide

**File:** `06_DELIVERED_FILES/Rail_Bazar_HT_Capacitor_Loss_Analysis_2026.xlsx`  
**Type:** editable scenario spreadsheet, not calibrated power-system simulation or formal capacitor approval.

## Nine worksheets and responsibilities
1. **Dashboard** — user-facing feeder metrics and before/after annual HT energy, net savings, legacy loss-factor comparison, PF summaries and chart. Formulas link to Inputs and model cases.
2. **Inputs** — editable assumptions, bank selection and period load profile. *Primary edit location*.
3. **Source Sections** — 98 real study-model electrical sections and formulas reproducing section losses, derived `R_eff`, QA flags and ancestor-path membership indicators. Don't overwrite baseline study columns.
4. **3-Period Model** — 98 × 3 = **294** section operating cases, before/after kW and kWh, sectional P,Q/current and capacitor impact.
5. **Candidate Screen** — 98 node-location screening rows for a **single** test bank under assumptions. Does NOT certify electrical topology/voltage limits or produce a full best multi-bank power-flow solution.
6. **Node Paths** — source-to-`ToNode` ancestor tags used to decide which sections a capacitor affects; needs switch-state validation.
7. **Conductor Summary** — sections, length, peak loss and illustrative capacitor effects grouped by conductor label.
8. **GIS QA** — length, multipart conductor and multiple-incoming topology issues, verification actions.
9. **Calculation Guide** — formulas/definitions and warning labels inside the workbook.

## Current sample input cells (verify in actual workbook after opening)
- `Inputs!B4`: **11 kV** fixed study bus voltage (assumption).
- `Inputs!B5`: **0.85** uniform lagging PF (assumption, not measured at nodes).
- `Inputs!B6`: **190 A** reported study source peak current (not live SCADA).
- `Inputs!B7`: **0.40** legacy load factor.
- `Inputs!B9`: sum of study peak section losses, expected **24.666 kW**.
- `Inputs!B10`: capacitor A `ToNode = 8320031`; `B11` **300 kVAr**; `B12` **FIXED**.
- `Inputs!B13`: capacitor B `ToNode = 8320073`; `B14` **150 kVAr**; `B15` **SWITCHED**.
- `Inputs!B16`: switched enable fraction **0.65** (simple illustrative load-threshold, NOT field controller setting).
- `Inputs!B17`: nominal capacitor bus **11 kV** (informative in existing simple model).
- `Inputs!B18`: active bank losses parameter default **zero**; do not interpret net savings as fully loss-inclusive.
- `Inputs!B19`: indicative X ohm/km **0.3** unverified, not complete physical R/X solver.
- Other period hours/fractions and enabled bank flags in Inputs rows ~25–27; review and ensure 8760 hours; `LF=0.4` legacy factor may not equal the three-period model's squared-load integral.

## How the existing workbook recalculates
A) For baseline, section study `LossKW` is scaled by the **square of the operating current fraction**.  
B) For each selected bank, calculate nominal kvar injected only on the precomputed *ancestor path* from feeder source to the bank `ToNode`.  
C) For each operating case, derive branch P,Q from the reported study branch current at assumed PF, subtract relevant kVAr, recalculate current magnitude and scale the study `LossKW` by squared current ratio.  
D) Multiply pre/post kW by each case's hours and sum to feeder annual HT kWh; calculate percent and kWh savings, subtract assumed bank active losses if provided.  
E) Candidate Screen is a **unverified sensitivity ranking** and is not the production optimiser in `engine.py`.

## Quick check sequence before changing the file
1. Make a copy, don't overwrite the source workbook; open in desktop Excel with automatic calculation on. Save to refresh formula caches. Google Sheets/LibreOffice may not preserve all formatting/charts/formulas identically.
2. Confirm exact baseline: 98 `Source Sections` rows; sum study lengths 5.247; sum study loss 24.666 kW; check source-current field 190 A at head.
3. Check duplicated geometry is not double counted. Cross-reference QA for `_25`, `_89`, `_92` and five multiple-incoming node ambiguities.
4. Set both kVAr fields to **zero**; before/after loss and kWh should then match (within numerical tolerance). Confirm before and after by period and total before reported savings.
5. Restore the illustrated scenario, check bank flags and 8760 hours. Interpret only as example, not installation proposal.
6. Test zero kvar, large kvar at light load, fixed vs switched control and changed PF; flag leading Q and potential overvoltage as **unassessed** rather than calculating fake compliance.
7. When extending, add actual conductor R/X, pole availability, transformer P/Q measurements, switch-state mapping, true voltage solution, bank active/reactive characteristics, economic data, and report status/approval history.

## Next version requests for new ChatGPT account
- Keep 9 existing tabs, create `Data Dictionary`, `Conductor Master`, `Metered Profiles`, `Topology QA`, `Protection & Harmonics`, `Scenario Register`, and `Installation Feasibility`, as separate linked sheets.
- Preserve original columns/IDs/source numbers untouched; highlight inputs distinctly from results. Add evidence/status fields for every assumption.
- Add full before/after per-section Amp, kW, kVAr, kV, %VD, annual kWh, conductor loading, grid PF (lag/lead), bank size/mode/on-off and avoided loss by path. For quantities not yet supported, use `REQUIRES DATA`, not fabricated outputs.
- Produce both **legacy loss reporting** and **new engineering scenario** in separate tabs or clearly marked methods; compare them, never mix denominators.
- Add formula and integrity tests and a professional printable installation-candidate report. Ensure recalculation works in Excel, not simply static values.
