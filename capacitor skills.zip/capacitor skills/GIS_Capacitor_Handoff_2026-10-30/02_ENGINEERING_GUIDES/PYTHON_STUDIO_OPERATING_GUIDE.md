# Python capacitor studio v0.1 — run and improve

**Delivered source:** `06_DELIVERED_FILES/HT_Capacitor_Placement_Studio_v01.zip` (also extracted under `08_PYTHON_STUDIO`). The program ships with SYNTHETIC sample feeder CSVs. Do not claim its recommended nodes are Rail Bazar locations.

## Contents
- `app.py` Streamlit portal with local upload, planning parameters, scenario UI, result downloads.
- `engine.py` balanced radial backward/forward sweep and feasibility/candidate ranking.
- `cli.py` automated local batch processing for feeder profiles.
- `sample_data/nodes.csv`, `sections.csv`, `profiles.csv` synthetic test network.
- `tests/test_engine.py` model-regression tests; `requirements.txt`, `run_windows.bat`.

## Run locally on Windows
Install Python 3.11+ with pip and, in the extracted studio directory, execute:

```powershell
py -m pip install -r requirements.txt
py -m streamlit run app.py
```

Or double-click `run_windows.bat` (inspect any .bat/.py before running downloaded code). CSV inputs remain on local PC in this local configuration; do not deploy sensitive utility GIS to public Streamlit Cloud.

Run headless:

```powershell
py cli.py --folder sample_data --source N0 --kind fixed --banks 2
```

## CSV data schema
- `nodes.csv`: `node_id,peak_kw,pf,x,y` (map coordinates x,y optional for visualisation; loads require confirmed coincident **kW**, not installed kVA).
- `sections.csv`: `section_id,from_node,to_node,length_km,r_ohm_per_km,x_ohm_per_km,ampacity_a`.
- `profiles.csv`: `period,hours,load_fraction` (hours total 8760 for full year).

## Physical model limitations
- Three-phase balanced PQ network, radial only, without actual Rail Bazar GIS + metering.
- Fixed shunts on for all load periods; switched controlled using a coarse load-fraction threshold, not real voltage/PF switching relay, deadband or time delay.
- Multi-bank scenario search is greedy and not proven global optimum; results are screening, not certified design.
- No transformer/LT/service line savings, commercial losses, 3-phase phase imbalance, on-load tap changers, regulator dynamics, harmonics or transients.

## How to adapt to Rail Bazar correctly
1. Read `rail_bazar_98_data.csv` (study sections only, **not** physically validated R/X input). Confirm 98-section and parent/ToNode ID integrity.
2. Resolve 5 multi-inbound electrical nodes and reconfiguration/switch state. Where the study tree selects one branch but GIS lists a tie, document the open switch and as-operated source. Do not invent closed/open states.
3. Reconstruct unique energized branch list; check duplicated IDs and geometries. Validate all conductor labels against electrical master to populate `R` and `X` ohm/km and ampacity.
4. Add node-wise coincident `P`,`Q` profiles using meters/transformers. A 190 A source-current alone cannot uniquely determine every node's kvar demand.
5. Compare no-cap solved current, peak kW loss and voltage profile against study and field readings; account for modelling differences and adjust only with evidence.
6. Run candidate site/size ranking and compare with spreadsheet sensitivity. Screens must enforce voltage, ampacity, negative grid Q, switching feasibility, harmonics/protection/maintenance and physical feasibility.
7. Export node/section identifiers, decision rationale, before/after period results, kWh, warning reasons, GeoJSON/KML and a printable engineering proposal.

**Important:** If a new account imports the 98-row study CSV directly into `engine.py` without topology fix/R/X/time series, the output will be invalid. Do NOT invent missing electrical parameters merely to show recommendations.
