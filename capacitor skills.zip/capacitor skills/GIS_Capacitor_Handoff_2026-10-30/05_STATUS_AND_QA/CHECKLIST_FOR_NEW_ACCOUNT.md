# 10-minute new-account self-check

[ ] Upload ZIP or extract + upload individual essential files.  
[ ] Paste `00_START_HERE/PASTE_THIS_PROMPT.txt`.  
[ ] Ask assistant to inventory files and explicitly read `.xlsx` and `rail_bazar_98_data.csv`.  
[ ] Confirm **98 / 5.247 / 24.666**, not guessed quantities.  
[ ] Confirm feeder study `117714`, GIS ID `832`, 190 A source study head current, 11 kV nominal.  
[ ] Preserve workbook source data; open/recalculate formulas; compare sheet counts.  
[ ] Treat 300kVAr@8320031 fixed and 150kVAr@8320073 switched as test-only.  
[ ] Ask for explanation of how the proposed bank impacts each upstream section, not whole feeder PF.  
[ ] Confirm missing R/X, actual kW-kVAr periods, voltage, switch states; mark unresolved.  
[ ] Select next task from `03_PROMPTS/READY_TO_USE_PROMPTS.md`.  
[ ] Request final updated editable file, downloadable local artifact, QA and assumptions table.  
[ ] Ask assistant not to publish sensitive utility GIS or rewrite existing repo without approval.
