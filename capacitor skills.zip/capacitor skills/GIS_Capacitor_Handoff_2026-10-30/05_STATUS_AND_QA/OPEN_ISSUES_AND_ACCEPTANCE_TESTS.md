# Open issues, status and strict acceptance checks

## Current status — 30 October 2026
- [x] Real study section data reconstructed into an accessible 98-row CSV and Excel source table.
- [x] Baseline model values: 98 HT sections / 5.247 study km / 24.666 kW study peak line loss.
- [x] Spreadsheet before/after two-bank scenario and editable input controls, three load periods.
- [x] Approximate single-bank candidate screen and source-path trace in Excel.
- [x] Separate balanced radial physical Python screening prototype with synthetic example data.
- [ ] Approved actual feeder topology and switch-state evidence (multi-inbound nodes unresolved).
- [ ] Traceable conductor per-type R/X at operating temperature, cable and overhead branches, ampacity, electrical master.
- [ ] Actual nodal kW/kVAr demand allocation and 15–60-minute data with source voltage/PF.
- [ ] Calibrated no-bank voltage and loss results against observations and utility engineering baseline.
- [ ] Correct fixed/switched controller model at low load and component active losses.
- [ ] Real geographic candidate poles validated against site access and utility operational restrictions.
- [ ] Harmonic resonance, switching transients, protection, fusing, earthing and detailed bank sizing.
- [ ] Actual bank quotation/cost, benefit-cost review, engineer sign-off/approval and field installation.
- [ ] Actual capacitor-location implementation in operational portal with safe deployment.

## Structural issues to preserve
- Feeder code `117714` ≠ GIS ID `832`.
- Study 5.247 km ≠ GIS 5.362 km (difference 115 m).
- 98 electrical study sections ≠ 101 GIS geometry pieces; avoid multipiece double count.
- Multi-inbound electrical nodes: five (review exact IDs/branch states in source workbook/QA).
- Mixed conductor geometry references: `HT_832_179_25`, `_89`, `_92`. Don't automatically replace study conductor with GIS conductor.
- Eight study/GIS section-length differences >1 m from previous QA; priority for source version validation.
- Transformer installed kVA 10,910 study vs 11,145 GIS: not coincident demand.
- Source model head current 190 A: not live telemetry.

## Required acceptance checks for every revision
1. No missing/duplicate raw section IDs. Source sheet remains unmodified, exact source rows retained.
2. Summary rows verify `COUNT=98`, `SUM study km=5.247`, `SUM study peak HT loss kW=24.666` within displayed-source precision.
3. `0 kVAr` both banks produces identical before/after section, peak and annual losses; residual < numerical tolerance.
4. A bus-bank changes only energised upstream paths, **never unrelated lateral sections** absent voltage/network interactions.
5. Correct units: kW vs kVA vs kVAr; no `sqrt(3)*V*I` mislabelled kW; Q sign and leading/lagging flagged.
6. Case hours sum 8760 (or explicitly declared other duration) and same periods compared before/after.
7. Low-load fixed bank may drive **negative grid Q / leading PF**; report as failure/risk if actual Q profile confirms it. Cannot mark pass when Q missing.
8. Capacitor savings cannot be inferred from whole-feeder PF improvement alone. Separate empirical/study/assumed quantities.
9. Model rejects unknown nodes, reversed/duplicated parent chains, multi-inbound energized nodes and nonsensical load data; don't auto-fix branches to make solver succeed.
10. Peak no-bank physical-model current/loss/voltage reconciles to externally validated study within documented tolerance; all deviations explained.
11. No capacitor installed by default. Candidate ranking displays physical feasibility, voltage/thermal/leading PF and QA warnings.
12. Segregate HT conductor vs transformation vs LT/service vs nontechnical loss — no double counting savings.
13. An engineering report exports before and after per SectionID, each case, kWh, PF, voltage when calculated, assumptions, calculation engine/version and approvals.
14. New user can open/run docs, sources, workbook and tests offline without an undisclosed credential. Public repo stays unmodified unless explicitly approved.
15. New package has explicit version/source provenance and reproducible checksums.

## Top risk / go-no-go
Current workbook is a **sensitivity analysis**, not a full power-flow/voltage/thermal approval. Current Python engine is **synthetic-only**. Do NOT describe any capacitor node as "optimal verified" or quote actual measured kWh saved unless topology, conductor data, nodal Q, min/max voltages and engineering/field verification support it.
