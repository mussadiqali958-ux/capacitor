# Project handover — scope, history, completed work

## 1) Main objective
Develop an integrated utility GIS / Distribution Network Intelligence Platform for Pakistan DISCOs: a shareable but access-controlled portal where validated high-tension (11 kV) and low-tension network GIS, transformer/consumer records, losses and load-flow analytics, planning interventions and reports share one versioned network model. The immediate module is **automatic, traceable capacitor placement** on the 11 kV HT network. It must evaluate *node location*, *bank size (kVAr)*, *fixed vs switched mode*, *before/after section currents*, *losses (kW, kWh)*, *voltage/PF*, *operating feasibility*, and potential savings/cost.

## 2) Broader portal context
Previous project goals include HT/LT line and transformer/consumer GIS, feeder → section → node topology, node-to-node load flow and losses, feeder data import, editable assumptions, hotspot map, dashboard, versioned data, 11 kV capacitor planning, authorised smart-meter/AMI integration, hazard risk overlays, government/NEPRA technical reporting and future CIM/PostGIS. Main hierarchy: DISCO → Circle → Division → Subdivision → Grid Station → Feeder → HT/LT → Transformer → Consumers. Core focus is utility planning and compliance, not just a visual mock-up.

Earlier City Grid pilot: 18 feeders in supplied GIS versus 19 FY25–26 feeder-study rows; Halal Road study feeder code 117709 was missing from supplied GIS geometry. Keep this as an **unresolved source/version mismatch**, not a fabricated feeder line.

## 3) Rail Bazar source-of-truth values from prior study review
- Feeder name: Rail Bazar; feeder study code `117714`; GIS feature ID `832` (not interchangeable).
- Latest GIS-linked study version: **98 HT model sections**, **5.247 km** study section length, **24.666 kW** modelled peak HT conductor loss, **190 A** peak study source-current estimate, **11 kV** nominal/assumed base.
- GIS model: **101 section geometry records**, GIS length **5.362 km** (difference **0.115 km**). Study IDs match GIS sections 98/98, but geometry count differs from electrical section count.
- **77** GIS transformer records; **4,330** GIS-linked surveyed consumer records; transformer nameplate sum GIS **11,145 kVA** and study local node nameplate sum **10,910 kVA** (235 kVA discrepancy). Nameplate values are not coincident peak kW.
- Five multi-inbound electrical node IDs and three mixed-conductor/multipart section IDs need operational/geometric reconciliation. **255 consumers** attributed to ambiguous paths in the prior QA.
- High-loss model sections include `HT_832_179_6` (3.876 kW OSPREY, 0.291 km), `_9` (3.210 kW OSPREY, 0.241 km), `_8` (3.104 kW OSPREY, 0.233 km), `_23` (1.829 kW RABBIT, 0.052 km), `_11` (1.599 kW OSPREY, 0.120 km). These are loss hotspots, **not automatically best capacitor sites**.
- These figures were compiled from earlier study outputs, not SCADA measurements. See `rail_bazar_98_data.csv` and the existing workbook for rows/lineage.

## 4) What was delivered (26–30 October 2026)
1. **Python/Streamlit prototype** `HT_Capacitor_Placement_Studio_v01.zip`: balanced radial 3-phase backward/forward sweep, candidate bank site and kVAr ranking, three load periods, fixed/switched simple load threshold, feasibility screens and outputs. It contains synthetic feeder examples, NOT a real Rail Bazar import. Included extracted sources under `08_PYTHON_STUDIO`.
2. **Revised engineering formula documents** in PDF and DOCX: new P/Q/PF, capacitor sizing, loss, annual kWh, and screening logic, plus comparison to user's existing formula document.
3. **Rail Bazar editable Excel** `Rail_Bazar_HT_Capacitor_Loss_Analysis_2026.xlsx` with nine tabs and original study source values. Recalculates illustrative upstream section current/loss impact for two selectable banks; candidate screens are unverified and topology dependent. Example: 300 kVAr fixed at study node 8320031, 150 kVAr switched at node 8320073. This is a simplified sensitivity workbook, not a full complex-voltage power flow.
4. Source CSV `rail_bazar_98_data.csv` and a dashboard preview PNG.

## 5) Previous reported illustrative results
The earlier Excel handoff described baseline annual HT loss of approximately **51,743 kWh**, after-bank scenario **44,963 kWh**, saving **6,780 kWh / 13.10%**. These are **previously reported model scenario values** (not independently certified / no measured interval data). Recalculate from the workbook and verify formula caches before using in a new report. These values must not be mixed with the separate synthetic Python demo (~343.6 → 274.3 MWh).

## 6) What remains and what must NOT be claimed
Not yet demonstrated: an approved network switching model; per-conductor physically measured/traceable R/X and seasonal temperature; real customer/transformer kW and kVAr time series; measured minimum PF and voltage; local installed capacitor inventory; harmonic impedance and resonance; regulator/tap behaviour; protection/fusing/earthing/clearance; true feeder-geometry placement map; measured annual savings; government approval. No changes to the existing private City Grid GIS or public GitHub were made as part of the previous Excel delivery.

Connected GitHub repository known from earlier context: `mussadiqnespak-oss/gridscope-demo` (public). It is **not the complete private City Grid GIS portal** by implication. Do not overwrite it, expose confidential utility asset information or assume the new account has connected GitHub permission.

## 7) User's working preferences
Deliver actual editable `.xlsx` workbooks and practical tools, not only explanations. Maintain original feeder codes/nodes/section IDs and formula traceability. Mark editable assumptions, preserve source sheets, audit mismatches, provide instructions and a clear dashboard. Emphasise accuracy, working formulas, network engineering, credible GIS, NEPRA/FESCO accountability and future extensibility.
