# Data dictionary and provenance

## `rail_bazar_98_data.csv` (source study reconstruction)
Columns: `num` (study section suffix), `from_node`, `to_node`, `parent_num` (0 is feeder root), `length_km`, `current_a` (study model section peak), `conductor` (study conductor label), `study_loss_kw` (rounded published section model peak HT loss), `cumm_vd_pct` (rounded study cumulative voltage-drop output). The combination `HT_832_179_<num>` reconstructs study SectionID; preserve suffix and source ordering. It has **98 data rows**.

**Do not infer** node real/reactive demand, exact conductor ohm/km, whole-system kWh, SCADA values, tap settings or physical switch states from this CSV. `study_loss_kw=0` can mean rounded small positive value, not proof the branch has zero R or zero loss.

## Excel import expectations
`Source Sections` adds GIS length and conductor QA from prior crosswalk, derived effective resistance and path indicators. Other model sheets contain assumptions, formulas and test scenario outputs. Actual GIS geometry/coordinates and a complete original transformer meter master are **not present** in the small study CSV; the sheet contains references/QA context rather than georeferenced line shapes.

## New datasets required (sample CSV templates included)
- **Conductor_Master.csv:** conductor label; R ohm/km at specified temperature; X ohm/km; ampacity; conductor type; field/supplier source and approval date.
- **Node_Load_Profile.csv:** node_id, timestamp/period, measured_or_estimated, coincident kW, signed lagging kvar, voltage, evidence.
- **Switch_State.csv:** switch asset ID, endpoints, normally open/closed, actual interval status, verification evidence.
- **Capacitor_Catalogue.csv:** bank kVAr, rated kV, fixed/switch steps, loss W/kVAr, controller details, rated current, protection requirements, costs and provenance.
- **Feeder_Measurements.csv:** source-grid timestamp, kV, A, kW, signed kVAr, PF lead/lag, metered kWh and source.
- **Candidate_Sites.csv:** ToNode, GIS pole coordinate only if verified, constructability, proximity, equipment clearance, ownership/approval, safety comments.

All new templates are empty: NOT actual FESCO/LESCO datasets and NOT imported into the existing workbook.
